
function doContrastedColorTheme(){
	     $("#sanskrittext").css("background-color", "black");
	     $("RMTEXT").css("color", "white");	     
	     $("DNTEXT").css("color", "white");   
	     $("RMAPP").css("color", "white");	     
	     $("DNAPP").css("color", "white");	     
	     $(".ms").css("color", "white"); 	     
	     $("LEM").css("color", "orange");	     
	     $("h1").find("RMTEXT").css("color", "white");	     
	     $("h1").find("DNTEXT").css("color", "white");	     
  	     $("chapter").find("RMTEXT").css("color", "orange");	     
  	     $("chapter").find("DNTEXT").css("color", "orange");	     
  	     $("subchapter").find("RMTEXT").css("color", "orange");	     
	     $("subchapter").find("DNTEXT").css("color", "orange");	     
   		  }
     
function doLightColorTheme(){  
	     $("#sanskrittext").css("background-color", "white");
	     $("RMTEXT").css("color", "black");	     
	     $("DNTEXT").css("color", "black");	     
	     $("RMAPP").css("color", "blue"); 
	     $("DNAPP").css("color", "blue"); 
	     $(".ms").css("color", "black"); 
	     $("INSTR").css("color", "blue");	     
	     $("LEM").css("color", "red");	     
	     $("h1").find("RMTEXT").css("color", "blue");	     
	     $("h1").find("DNTEXT").css("color", "blue");	     
  	     $("chapter").find("RMTEXT").css("color", "orange");  
 	     $("chapter").find("DNTEXT").css("color", "orange");	     
	     $("subchapter").find("RMTEXT").css("color", "orange");	     
	     $("subchapter").find("DNTEXT").css("color", "orange");	     
     	            }
	     	            
function doGrayColorTheme(){  	            
	     $("#sanskrittext").css("background-color", "black");
	     $("RMTEXT").css("color", "gray");     
	     $("RMAPP").css("color", "gray"); 
      	     $("DNAPP").css("color", "gray"); 
             $("DNTEXT").css("color", "gray"); 
   	     $(".ms").css("color", "gray");	 
	     $("APP").css("color", "gray");	  
     	     $("LEM").css("color", "gray");	        
	     $("h1").find("RMTEXT").css("color", "orange");	     
	     $("h1").find("DNTEXT").css("color", "orange");	     
  	     $("chapter").find("RMTEXT").css("color", "orange");	     
  	     $("chapter").find("DNTEXT").css("color", "orange");	     
	     $("subchapter").find("RMTEXT").css("color", "orange");	     
	     $("subchapter").find("DNTEXT").css("color", "orange");	     
	       }

  
